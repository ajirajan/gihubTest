$(document).ready(function () {
  $("#studentDropdownTree").kendoDropDownTree({
    placeholder: "Select ...",
    checkboxes: {
      checkChildren: true
    },
    filter: "startswith",
    checkAll: false,
    autoClose: false,
    dataSource: [
      {
        id: 1, text: "Section A", expanded: true, items: [
          { id: 2, text: "13100100046467   |   Joan Jeeha" },
          { id: 3, text: "13100100046467   |   Joan Jeeha" },
          { id: 4, text: "13100100046467   |   Joan Jeeha" },
          { id: 5, text: "13100100046467   |   Joan Jeeha" }
        ]
      },
      {
        id: 6, text: "Section B", expanded: true, items: [
          { id: 7, text: "13100100046467   |   Joan Jeeha" },
          { id: 8, text: "13100100046467   |   Joan Jeeha" },
          { id: 9, text: "13100100046467   |   Joan Jeeha" },
          { id: 10, text: "13100100046467   |   Joan Jeeha" }
        ]
      },
    ],
    enable: true  // for disabled language dropdown
  });
  $("#staffDropdownTree").kendoDropDownTree({
    placeholder: "Select ...",
    checkboxes: {
      checkChildren: true
    },
    filter: "startswith",
    checkAll: false,
    autoClose: false,
    dataSource: [
      {
        id: 1, text: "10022361 - Abdul"
      },
      {
        id: 1, text: "10022361 - Abdul"
      },
      {
        id: 1, text: "10022361 - Aman Sharma"
      },
      {
        id: 1, text: "10022361 - Abdul"
      },
      {
        id: 1, text: "10022361 - Abdul"
      }
    ],
    enable: true  // for disabled language dropdown
  });
  $("#departureTimeControl").datetimepicker({
    format: "LT",
    allowInputToggle: true,
    icons: {
      up: "fa fa-chevron-up",
      down: "fa fa-chevron-down"
    }
  });
});

function showTransportForm() {
  var form = document.getElementById("student-transport-form");
  var main = document.getElementById("student-transport-main");
  var addNewButton = document.getElementById('add-new');
  if (form.style.display === "none") {
    form.style.display = "block";
    main.style.display = "none";
    addNewButton.style.display = "none";
  }
}
function showStudentTransportMain() {
  var form = document.getElementById("student-transport-form");
  var main = document.getElementById("student-transport-main");
  var addNewButton = document.getElementById('add-new');
  if (main.style.display === "none") {
    main.style.display = "block";
    form.style.display = "none";
    addNewButton.style.display = "inline-flex";
  }
}
