$(document).ready(function () {
  // TODO: Remove if not needed
  // $('.btn-wrap .button').click(function () {
  //   $('.fee-detail-wrapper').removeClass('hide-filters');
  // });

  $('.view-more').click(function () {
    $('.dropdown-list').slideToggle('fast');
  });

  $(document).on('click', function (e) {
    const container = $('.view-more');
    if (!container.is(e.target) && container.has(e.target).length === 0) {
      $('.dropdown-list').slideUp('fast');
    }
  });
})