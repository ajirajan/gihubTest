$(document).ready(function () {
    const pickr = new Pickr({
        el: '.color-picker',
        default: '#0180ff',
        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr.on('change', function (color) {
        $("#colorValue").text(color.toHEXA().toString());
    });
    pickr.on('save', function () {
        pickr.hide();
    });
    $('#colorValue').text("#0180ff");

    // Parent Permission tab table color picker code
    const pickr1 = new Pickr({
        el: '.color-picker-1',

        default: '#ff6565',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr1.on('change', function (color) {
        $("#colorValue1").text(color.toHEXA().toString());
    });
    pickr1.on('save', function () {
        pickr1.hide();
    });
    $('#colorValue1').text("#ff6565");

    const pickr2 = new Pickr({
        el: '.color-picker-2',

        default: '#eaea57',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr2.on('change', function (color) {
        $("#colorValue2").text(color.toHEXA().toString());
    });
    pickr2.on('save', function () {
        pickr2.hide();
    });
    $('#colorValue2').text("#eaea57");

    const pickr3 = new Pickr({
        el: '.color-picker-3',

        default: '#5878ff',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr3.on('change', function (color) {
        $("#colorValue3").text(color.toHEXA().toString());
    });
    pickr3.on('save', function () {
        pickr3.hide();
    });
    $('#colorValue3').text("#5878ff");

    const pickr4 = new Pickr({
        el: '.color-picker-4',

        default: '#67ed67',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr4.on('change', function (color) {
        $("#colorValue4").text(color.toHEXA().toString());
    });
    pickr4.on('save', function () {
        pickr4.hide();
    });
    $('#colorValue4').text("#67ed67");

    const pickr5 = new Pickr({
        el: '.color-picker-5',

        default: '#ff6565',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr5.on('change', function (color) {
        $("#colorValue5").text(color.toHEXA().toString());
    });
    pickr5.on('save', function () {
        pickr5.hide();
    });
    $('#colorValue5').text("#ff6565");

    const pickr6 = new Pickr({
        el: '.color-picker-6',

        default: '#eaea57',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr6.on('change', function (color) {
        $("#colorValue6").text(color.toHEXA().toString());
    });
    pickr6.on('save', function () {
        pickr6.hide();
    });
    $('#colorValue6').text("#eaea57");

    const pickr7 = new Pickr({
        el: '.color-picker-7',

        default: '#5878ff',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr7.on('change', function (color) {
        $("#colorValue7").text(color.toHEXA().toString());
    });
    pickr7.on('save', function () {
        pickr7.hide();
    });
    $('#colorValue7').text("#5878ff");

    const pickr8 = new Pickr({
        el: '.color-picker-8',

        default: '#67ed67',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr8.on('change', function (color) {
        $("#colorValue8").text(color.toHEXA().toString());
    });
    pickr8.on('save', function () {
        pickr8.hide();
    });
    $('#colorValue8').text("#67ed67");

    const pickr9 = new Pickr({
        el: '.color-picker-9',

        default: '#eaea57',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr9.on('change', function (color) {
        $("#colorValue9").text(color.toHEXA().toString());
    });
    pickr9.on('save', function () {
        pickr9.hide();
    });
    $('#colorValue9').text("#eaea57");

    const pickr10 = new Pickr({
        el: '.color-picker-10',

        default: '#ff6565',

        components: {
            preview: true,
            opacity: true,
            hue: true,

            interaction: {
                hex: true,
                rgba: true,
                hsva: true,
                input: true,
                save: true
            }
        }
    });
    pickr10.on('change', function (color) {
        $("#colorValue10").text(color.toHEXA().toString());
    });
    pickr10.on('save', function () {
        pickr10.hide();
    });
    $('#colorValue10').text("#ff6565");
});
