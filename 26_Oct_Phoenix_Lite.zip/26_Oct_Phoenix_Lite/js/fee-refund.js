$(document).ready(function () {
    $.fn.DataTable &&  $('#feeRefundRequestPendingTable1').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });
});

$(document).ready(function () {
    $.fn.DataTable &&  $('#feeReminderSearchTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });
});

$(document).ready(function () {
    $.fn.DataTable &&  $('#feeReminderSearchTable2').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });
});

$(document).ready(function () {
    $.fn.DataTable &&  $('#feeReminderSearchTable3').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });
});