$(document).ready(function() {
    var scrollBarWidths = 92;

    var widthOfList = function(){
        var itemsWidth = 0;
        $('.tab-list .nav-item').each(function(i) {
            var itemWidth = $(this).outerWidth(true);
            itemsWidth+=itemWidth;
        });
        return itemsWidth;
    };

    var widthOfHidden = function(){
        var ww = 0 - $('.custom-tabs').outerWidth(true);
        var hw = (($('.custom-tabs').outerWidth(true))-widthOfList()-getLeftPosi())-scrollBarWidths;
        var rp = $(document).width() - ($('.nav-item .nav-link').last().offset().left + $('.nav-item .nav-link').last().outerWidth(true));

        if (ww>hw) {
            return (rp>ww?rp:ww);
        }
        else {
            return (rp>hw?rp:hw);
        }
    };

    var getLeftPosi = function(){
        var ww = 0 - $('.custom-tabs').outerWidth(true);
        var lp = $('.tab-list').position().left;
        if (ww>lp) {
            return ww;
        }
        else {
            return lp;
        }
    };

    var reAdjust = function(){
        var rp = $(document).width() - ($('.nav-item .nav-link').last().offset().left);
        if (($('.custom-tabs').outerWidth(true)) < widthOfList() && (rp<0)) {
            $('.scroller-right').show().css('display', 'flex');
        }

        else {
            $('.scroller-right').hide();
        }

        if (getLeftPosi()<0) {
            $('.scroller-left').show().css('display', 'flex');
        }

        else {
            $('.nav-item .nav-link').animate({left:"-="+getLeftPosi()+"px"},'slow');
            $('.scroller-left').hide();
        }

        console.log("Readjust=======", rp)
    };

    reAdjust();

    $('.scroller-right').click(function() {
        $('.scroller-left').fadeIn('slow');
        $('.scroller-right').fadeOut('slow');

        var rp = $(document).width() - ($('.nav-item .nav-link').last().offset().left);
        if (($('.custom-tabs').outerWidth(true)) < widthOfList() && (rp<0)) {
            $('.scroller-right').show().css('display', 'flex');
        }

        else {
            $('.scroller-right').hide();
        }
        var buttonWidth = widthOfHidden() - 46;
        $('.tab-list').animate({left:"+="+buttonWidth+"px"},'slow',function(){
            reAdjust();
        });
    });

    $('.scroller-left').click(function() {

        $('.scroller-right').fadeIn('slow');
        $('.scroller-left').fadeOut('slow');

        $('.tab-list').animate({left:"-="+getLeftPosi()+"px"},'slow',function(){
            reAdjust();
        });
    });
});
