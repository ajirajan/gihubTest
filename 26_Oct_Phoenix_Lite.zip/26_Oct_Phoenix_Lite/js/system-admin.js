$(document).ready(function() {

        $(".system-admin-manage-rights .multiselect-dropdown .multiselect-container li label").on("click", function(){
            $('.system-admin-manage-rights .hidden_first').removeClass('hidden_first');
        });

        $('.show_content button').on("click", function(){
            $('.hide_content').css("display","block");
            $('.show_content button').hide();
        });


        $.fn.kendoDropDownTree && $("#savemodaldropdowntree").kendoDropDownTree({
            placeholder: "Select ...",
            checkboxes: {
                checkChildren: true
            },
            // filter: "startswith",
            checkAll: false,
            autoClose: false,
            dataSource: [
                {
                    id:1, text: "Gems School - Dubai",
                },
                {
                    id:2, text: "Bright Bus Transport",
                },
                {
                    id:3, text: "Bright Bus Transport",
                },
                {
                    id:4, text: "Bright Bus Transport",
                }
            ]
        });

        $('.Confirm-click').on('click',function(){
            $('.right_table.left_table').removeClass('grade_column');
            $('.right_table.left_table').prev().removeClass('d-flex');
            $('.right_table.left_table').prev().addClass('grade_column');
            $('.reset_add .d-none').removeClass('d-none');

            $('.Confirm-click').hide();
        })
        
        $('.Add_button').on("click", function(){
            $('.scrollable-table').removeClass('d-none');
            $('.cancel-save').removeClass('d-none');
            $('.Confirm-click').show();
            $('.reset_add .Add_button').parent().hide();

        });
})