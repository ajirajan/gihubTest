$( document ).ready(function() {
    //Hide all interactions except Main page
    $('#add-new-main').hide();
    $('#add-teacher-list').hide();
    $('#allocate-students-list').hide();
    $('#teacher-allocate-list').hide();
    $('#group-master-view').hide();


    //Page Change on CTAs
    $('#modal-add-teacher').on("click", function () {
        $('#add-teacher-list').show();
        $('#add-new-modal-cta').hide();
    });


    $('#save-allocate-student').on("click", function () {
        $('#allocate-students-list').show();
        $('#add-new-modal-cta').hide();
    });

    $('#group-master-add-new').on("click", function () {
        $('#add-new-main').show();
        $('#add-new-modal-cta').show();
        $('#group-master-main').hide();
    });

    $('#allocate-cancel').on("click", function () {
        $('#group-master-main').show();
        $('#allocate-students-list').hide();
        $('#add-new-main').hide();
    });

    $('#teacher-cancel').on("click", function () {
        $('#group-master-main').show();
        $('#add-teacher-list').hide();
        $('#add-new-main').hide();
        $('#add-new-modal-cta').hide();
    });

    $('#teacher-save').on("click", function () {
        $('#add-teacher-list').hide();
        $('#add-new-main').show();
        $('#add-new-modal-cta').hide();
        $('#teacher-allocate-list').show();
    });

    $('#teacher-allocate-cancel').on("click", function () {
        $('#group-master-main').show();
        $('#teacher-allocate-list').hide();
        $('#add-new-main').hide();
        $('#add-new-modal-cta').hide();
    });

});