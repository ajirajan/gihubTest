$(document).ready(function() {
    $.fn.DataTable &&  $('#advanceTaxInvoiceTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
        "bPaginate": false
    });

    $.fn.DataTable &&  $('#newAdvanceTaxInvoiceTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },

    });

    //dropdown for select-term --->>
    $("#invoiceSelectTermBtn").hide();
    $("#selectTermBtnDropdown").on('click',function (e) {
        $("#invoiceSelectTermBtn").toggle();
    });

    //New fee reminder -->

    //data-table
    $.fn.DataTable &&  $('#newFeeReminderTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        }
    });

    //New proForma invoice -->
      //data-table
    $.fn.DataTable &&  $('#newproformaTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        }
    });

    //modal table
    $.fn.DataTable && $('#newproformaModalTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    //fee-profile-student-detail
    //data-table
    $.fn.DataTable &&  $('#feeProfilestudentDetailTable1').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        }
    });
    $.fn.DataTable &&  $('#feeProfilestudentDetailTable2').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        }
    });
    $.fn.DataTable &&  $('#feeProfilestudentDetailTable3').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 50,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        }
    });
});

$(document).ready(function() {
    $("#newProFormaInvoiceSecondFold").hide();
    $("#newProformaAddDetailBtn").on('click',function () {
        $("#newProFormaInvoiceSecondFold").show();
    });
    $("#newProformaDeleteDetailsBtn").on('click',function () {
        $("#newProFormaInvoiceSecondFold").hide();
    });

    $("#newProformaEditDetailsBtn").on('click',function () {
        $("#newProformaEditModal").show();
    });

    $("#proformaModalOkBtn").on('click',function () {
        $("#newProformaEditModal").hide();
    });
});

//new-advance tax dropdown -->
$(document).ready(function(){
    $("#feeTypeSelect").change(function(){
        $(this).find("option:selected").each(function(){
            if($("#feeTypeSelect").val() == "Tuition Fee"){
                $("#tuitionFeeContentBox").show();
                console.log('value selected-->' );
            } else {
                $("#tuitionFeeContentBox").hide();
            }
        });
    }).change();
});

//new fee-reminder -->>
$(document).ready(function() {
    //open-close student list
    $("#newFeeReminderSecondFold").hide();
    $("#newFeeeOpenCloseStudentListBtn").on('click',function (e) {
        if ($(this).text() == 'Close Student List') {
            $(this).text("View Student List");
            $("#newFeeReminderFirstFoldFooter").show();
        }
        else {
            if ($(this).text() == 'View Student List') {
                $(this).text("Close Student List");
                $("#newFeeReminderFirstFoldFooter").hide();
            }
        }
        $("#newFeeReminderSecondFold").toggle();
    });

    $("#newFeeSecondFoldSaveBtn").on('click',function () {

        $("#newFeeReminderSecondFold").hide();
        $("#newFeeeOpenCloseStudentListBtn").text("View Student List");
        $("#newFeeReminderFirstFoldFooter").show();
    })
});
