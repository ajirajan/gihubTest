document.addEventListener('DOMContentLoaded', function () {
    $('.multiselect-dropdown select').each(function () {

// Cache the number of options
        var $this = $(this),
            numberOfOptions = $(this).children('option').length;

// Hides the select element
        $this.addClass('s-hidden');

// Wrap the select element in a div
        $this.wrap('<div class="selected_item"></div>');

// Insert a styled div to sit over the top of the hidden select element
        $this.after('<div class="styledSelect"></div>');

// Cache the styled div
        var $styledSelect = $this.next('div.styledSelect');

// Show the first select option in the styled div
        $styledSelect.text($this.children('option').eq(0).text());

// Insert an unordered list after the styled div and also cache the list
        var $list = $('<ul />', {
            'class': 'options'
        }).insertAfter($styledSelect);

// Insert a list item into the unordered list for each select option
        for (var i = 0; i < numberOfOptions; i++) {
            $('<li />', {
                text: $this.children('option').eq(i).text(),
                rel: $this.children('option').eq(i).val(),
                class: i === 0 ? 'selected' : ''
            }).appendTo($list);
        }

// Cache the list items
        var $listItems = $list.children('li');
// Show the unordered list when the styled div is clicked (also hides it if the div is clicked again)
        $styledSelect.click(function (e) {
            e.stopPropagation();
            $('div.styledSelect.active').each(function () {
                $(this).removeClass('active').next('ul.options').hide();
            });
            $(this).toggleClass('active').next('ul.options').toggle();
        });

// Hides the unordered list when a list item is clicked and updates the styled div to show the selected list item
// Updates the select element to have the value of the equivalent option
        $listItems.click(function (e) {
            e.stopPropagation();
            $styledSelect.text($(this).text()).removeClass('active');
            $this.val($(this).attr('rel'));
            $(this).addClass('selected').siblings().removeClass('selected');
            $list.hide();
            /* alert($this.val()); Uncomment this for demonstration! */
        });

// Hides the unordered list when clicking outside of it
        $(document).click(function () {
            $styledSelect.removeClass('active');
            $list.hide();
        });
    });

    // toaster message
    $('.toast').delay(1000).fadeOut(2000);

    $.fn.kendoDropDownTree && $("#languageTreeDropdown").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "English"
            },
            {
                id:1, text: "Arabic"
            },
            {
                id:1, text: "French"
            },
            {
                id:1, text: "Hindi"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#widgetTreeDropdown").kendoDropDownTree({
        placeholder: "Select Widget",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "My Task"
            },
            {
                id:2, text: "My Leaves"
            },
            {
                id:3, text: "My Team"
            },
            {
                id:4, text: "My Calendar"
            },
            {
                id:5, text: "Daily Reports"
            }
        ],
        enable: true  // for disabled language dropdown
    });
});

$(document).ready(function() {
    $.fn.DataTable &&  $('#sampleTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.DataTable &&  $('#horizontalScrollDataTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        },
        "scrollX": true, // scrollX: true // for showing horizontal scroll, but it will specify when number of columns more than view
        "sScrollXInner": "100%",
    });

    $('#globalSearch').on( 'keyup', function () {
        table.search( this.value ).draw();
    } );

    $.fn.datepicker && ($.fn.datepicker.defaults.autoclose = true);
    $.fn.datepicker && ($.fn.datepicker.defaults.format = "dd/M/yyyy");

    $.fn.datepicker && $('.datepicker').datepicker({});

    $.fn.datetimepicker && $("#timepicker, .time").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });

    $.fn.datetimepicker && $("#gatePassTimePicker").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });
    $.fn.datetimepicker && $("#gatePassModalTimePicker").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });

    //    file upload Js
    $('#chooseFile').bind('change', function () {
        var filename = $("#chooseFile").val();
        if (/^\s*$/.test(filename)) {
            $(".file-upload").removeClass('selected');
            $("#noFile").text("No file chosen...");
        }
        else {
            $(".file-upload").addClass('selected');
            $("#noFile").text(filename.replace("C:\\fakepath\\", ""));
        }
    });

    $('.notification_btn').click(function(){
        $(this).siblings(".mob_dsign").toggle();
    });

    // Multiselect dropdown with search
    $.fn.multiselect && $('#framework').multiselect({
        nonSelectedText: 'Select Framework',
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth:'400px'
    });

    // tree view dropdown
    $.fn.kendoDropDownTree && $("#dropdowntree").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        // filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "United Arab Amirat", expanded: true, items: [
                    { id: 2, text: "New Zealand" },
                    { id: 3, text: "USA" },
                    { id: 4, text: "London"},
                    { id: 5, text: "Hong Kong"}
                ]
            },
            {
                id: 6, text: "Asia", items: [
                    { id: 7, text: "New Delhi", expanded: true, items: [
                            { id: 8, text: "USA" },
                            { id: 9, text: "London"},
                            { id: 10, text: "Hong Kong"}
                        ]
                    },
                    { id: 11, text: "Mumbai" },
                    { id: 12, text: "Bihar" },
                    { id: 13, text: "Chennai" }
                ]
            },
            {
                id: 14, text: "India", items: [
                    { id: 15, text: "New Delhi" },
                    { id: 16, text: "Mumbai" },
                    { id: 17, text: "Bihar" },
                    { id: 18, text: "Chennai" }
                ]
            },
            {
                id: 15, text: "Select all", items: [
                    { id: 16, text: "", expanded: true, items:[
                            { id: 17, text: "USA" },
                            { id: 18, text: "London"},
                            { id: 19, text: "Hong Kong"}
                        ]
                    },
                    { id: 20, text: "Mumbai" },
                    { id: 22, text: "Bihar" },
                    { id: 23, text: "Chennai" }
                ]
            }
        ]
    });

    // dropdown with search
    $.fn.multiselect && $('#country').multiselect({
        nonSelectedText: 'Select Framework',
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth:'400px'
    });

    // custom accordion
    let acc = document.getElementsByClassName("custom-accordion");
    let i;

    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function() {
            this.classList.toggle("active");
            let panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.scrollHeight !== 0 ?
                    panel.style.maxHeight = panel.scrollHeight + "px" :
                    panel.style.maxHeight = "fit-content";
            }
        });
    }
    acc.length && acc[0].click();
});


$(document).on('show.bs.modal', '#approvalConfirmation', function (e) {
    $("#critical-information-modal").modal("hide");
});

//sibling-info-search-toggle

$(function () {
    $("#sibling-info-box").hide();
    $("#sibling-search-btn").bind("click", function () {
        $("#sibling-search-box").hide();
        $("#sibling-info-box").show();
        $("#accordion-content-info").css("max-height", 400);
    });

    $("#sibling-info-cancel").bind("click", function () {
        $("#sibling-info-box").hide();
        $("#sibling-search-box").show();
        $("#accordion-content-info").css("max-height", 230);
    });

    $("parent-accordion-content").css("max-height",900);
});

$(function () {
    $("#snapshot-sibling-info-box").hide();
    $("#snapshot-sibling-search-btn").bind("click", function () {
        $("#snapshot-sibling-search-box").hide();
        $("#snapshot-sibling-info-box").show();
        $("#accordion-content-info").css("max-height", 400);
    });

    $("#snapshot-sibling-info-cancel").bind("click", function () {
        $("#snapshot-sibling-info-box").hide();
        $("#snapshot-sibling-search-box").show();
        $("#accordion-content-info").css("max-height", 230);
    });

    $("parent-accordion-content").css("max-height",900);
});

$(document).on("click","a.data-type",function(e){
    e.preventDefault();
    var id = $(this).attr("href");
    $(id).trigger( "click" );
    $('.phoenix-right-panel').animate({
        scrollTop: $(id).offset().top - 120
    }, 1000);
});

$(function () {
    // right side dropdowns---->
    $('#quick-tool-dropdown').hide();
    $('#sr-dot-btn').on('click', function (e) {
        $('#quick-tool-dropdown').toggle();
    });

    $('#quick-tool-dropdown-1').hide();
    $('#sr-dot-btn-1').on('click', function (e) {
        $('#quick-tool-dropdown-1').toggle();
    });


    $('#quick-tool-dropdown-2').hide();
    $('#sr-dot-btn-2').on('click', function (e) {
        $('#quick-tool-dropdown-2').toggle();
    });


    $('#quick-tool-dropdown-3').hide();
    $('#sr-dot-btn-3').on('click', function (e) {
        $('#quick-tool-dropdown-3').toggle();
    });


    $('#quick-tool-dropdown-4').hide();
    $('#sr-dot-btn-4').on('click', function (e) {
        $('#quick-tool-dropdown-4').toggle();
    });


    $('#quick-tool-dropdown-5').hide();
    $('#sr-dot-btn-5').on('click', function (e) {
        $('#quick-tool-dropdown-5').toggle();
    });


    $('#quick-tool-dropdown-6').hide();
    $('#sr-dot-btn-6').on('click', function (e) {
        $('#quick-tool-dropdown-6').toggle();
    });


    $('#quick-tool-dropdown-7').hide();
    $('#sr-dot-btn-7').on('click', function (e) {
        $('#quick-tool-dropdown-7').toggle();
    });
});

$(document).on('show.bs.modal', '#confirmShortListModal', function (e) {
    $("#shortListEnquiryModal").modal("hide");
});

$(document).on('show.bs.modal', '#somethingWrongModal', function (e) {
    $("#shortListEnquiryModal").modal("hide");
});

$(document).on('show.bs.modal', '#somethingWrongModal', function (e) {
    $("#offerLetterModal").modal("hide");
});

// Change page (eg: listing to form page in right panel)
function swapPage (from, to) {
    var page1 = document.getElementById(from);
    var page2 = document.getElementById(to);
    if (page2 && page2.style.display === "none") {
        page2.style.display = "block";
        page1.style.display = "none";
    }
}

$(function () {
// select javascript
    $("select").change(function () {
        if($(this).val() === "") {
            $(this).addClass("empty-value");
        }
        else {
            $(this).removeClass("empty-value");
        }
    });
    $("select").change();
});

$(document).ready(function () {
    $('.custom-dropdown').hide();
    $('.show-custom-dropdown').click(function (e) {
        e.preventDefault();
        $('.custom-dropdown').toggle();
    });
});

$(document).mouseup(function(e) {
    var container = $(".custom-dropdown");
    if (!container.is(e.target) && container.has(e.target).length === 0) {
        container.fadeOut();
    }
});

$(function(){
    $.fn.resizeselect = function(settings) {
        return this.each(function() {

            $(this).change(function(){
                var $this = $(this);

                // create test element
                var text = $this.find("option:selected").text();

                var $test = $("<span>").html(text).css({
                    "visibility": "hidden"
                });


                $test.appendTo($this.parent());
                var width = $test.width()  + 0;
                $test.remove();

                $this.width(width);

            }).change();

        });
    };

    // run by default
    $("select.resizeselect").resizeselect();
});
