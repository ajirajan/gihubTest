$(document).ready(function() {
    $.fn.DataTable && $('#debtFollowUpTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        },
        "bPaginate": false,
    });


});
