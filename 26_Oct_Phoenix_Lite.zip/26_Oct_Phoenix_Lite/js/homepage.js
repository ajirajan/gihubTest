function chnageMyTeamTab(that, tableClass) {
    if ($(that).hasClass('selected')) {
        return false;
    } else {
        $('.my-team-list').removeClass('selected');
        $(that).addClass('selected');
        $('.my-team-table').addClass('hidden')
        $(tableClass).removeClass('hidden')
    }
}

function chnageMyCalanderTab (that, tableClass) {
    if ($(that).hasClass('selected')) {
        return false;
    } else {
        $('.my-calander-list').removeClass('selected');
        $(that).addClass('selected');
        $('.my-calander-table').addClass('hidden')
        $(tableClass).removeClass('hidden')
    }
}

function changePage (className) {
    $('.phoenix-page-container').removeClass('selected');
    $(className).addClass('selected');
}

function changeTheme (themeName) {
    $('body').attr('class', '');
    $('body').addClass(themeName);
}

$(document).ready(function(){
  $('.secondary-nav-items').click(function(){
    $('.secondary-nav-items').removeClass('selected');
    $(this).addClass('selected');
  });

});

$(document).ready(function () {
    /**
     * code to show hide submenu in sidebar
     */
    $('.secondary-nav-items').click(function () {
        if ($(this).hasClass('sub-menu-expanded')) {
            $(this).next('.nav_sub_menu').removeClass('show');
            $(this).removeClass('sub-menu-expanded');
        } else {
            $('.secondary-nav-items').removeClass('sub-menu-expanded');
            $(this).addClass('sub-menu-expanded');
            $('.nav_sub_menu').removeClass('show');
            $(this).next('.nav_sub_menu').addClass('show');
        }

    })
    /**
     * code to open submenu popup
     */
//   $('.nav_sub_menu li').click(function(){
//     if(!$(this).find('.nav_options').length){
//       return false;
//     }
//     else{
//       if($(this).hasClass('option-opened')){
//         $(this).removeClass('option-opened');
//         $(this).find('.nav_options').removeClass('show');
//       }
//       else{
//         $('.nav_sub_menu li').removeClass('option-opened');
//         $('.nav_options').removeClass('show');
//         $(this).addClass('option-opened');
//         $(this).find('.nav_options').addClass('show');
//       }
//     }

//   })
    /**
     * code to hide submenu option popup on clicking any where else in document
     */
    $(document).click(function (e) {
        if (!$(e.target).parents('.option-opened').length) {
            $('.nav_sub_menu li').removeClass('option-opened');
            $('.nav_options').removeClass('show');
        }
        /**
         * code to hide school search panel on clicking anywhere else in document
         */
        if ((!$(e.target).parents('#searchPanel').length) && (!$(e.target).parents('.school-batch-container').length)) {
            $('#searchPanel').removeClass('show');
        }

    });
    /**
     * code to show school search panel
     */
    $('.school-batch-container').click(function () {
        if (!$('#searchPanel').hasClass('show')) {
            $('#searchPanel').addClass('show');
        } else {
            $('#searchPanel').removeClass('show');
        }
    })
    $('.drag_action').click(function () {
        $('body').addClass('drag');
    })

    $('.drag_icons span').click(function () {
        $('body').removeClass('drag');
    })

    $('#shortlist_confirm_btn').click(function () {
        $('.show_register_form').addClass('show');
        $('.show_Shortlist_form').addClass('hide');

        $('#step-new-enquiry').addClass('checked');
        $('#step-shortlist-enquiry').addClass('selected');
    })
    $('.enrolment_list_btn').click(function () {
        $('.offer_letter_list').removeClass('show');
        $('.enrollment_list').addClass('show');
        $('.offer-letter-print').show();

        $('#step-register').addClass('checked');
        $('#step-offer-letter').addClass('selected');
      });
      $('.offer_letter_form').click(function () {
        $('.offer_letter_list').addClass('show');
        $('.show_register_form').removeClass('show');
        $('.register-slip-button').show();

        $('#step-shortlist-enquiry').addClass('checked');
        $('#step-register').addClass('selected');
    });

    $('.edit').click(function () {
        $('.action_buttons').addClass('show');
        $('.delete_section').addClass('show');
        $('.edit').addClass('hide');
    })

    $('.action_buttons button').click(function () {
        $('.action_buttons').removeClass('show');
        $('.delete_section').removeClass('show');
        $('.edit').removeClass('hide');
    })
})

$(document).ready(function () {
    function addSVGClass(){
        // For each image with an SVG class, execute the following function.
        $("img.svg").each(function () {
            // Perf tip: Cache the image as jQuery object so that we don't use the selector muliple times.
            var $img = jQuery(this);
            // Get all the attributes.
            var attributes = $img.prop("attributes");
            // Get the image's URL.
            var imgURL = $img.attr("src");
            // Fire an AJAX GET request to the URL.
            $.get(imgURL, function (data) {
                // The data you get includes the document type definition, which we don't need.
                // We are only interested in the <svg> tag inside that.
                var $svg = $(data).find('svg');
                // Remove any invalid XML tags as per http://validator.w3.org
                $svg = $svg.removeAttr('xmlns:a');
                // Loop through original image's attributes and apply on SVG
                $.each(attributes, function () {
                    $svg.attr(this.name, this.value);
                });
                // Replace image with new SVG
                $img.replaceWith($svg);
            });
        });
    }
    addSVGClass();

    $('.pagination .next-icon').click(function () {
        addSVGClass();
    });

//  Homepage Search btn
    $('.clear-btn').hide();
    $('.phoenix-g-search-input').keyup(function () {
        $('.clear-btn').show();
    });

    $('.phoenix-g-search-input').focusout(function () {
        $('.clear-btn').hide();
    })
});

$(window).on('load', function () {
  $('.salary-revision-accordion').click();
});
