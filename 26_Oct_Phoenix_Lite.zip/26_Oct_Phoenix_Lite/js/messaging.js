$(document).ready(function() {
    $.fn.DataTable && $('#emailDetailTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });
    $.fn.DataTable && $('#selectConcessionTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });
    $.fn.DataTable && $('#manageGroupTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.kendoDropDownTree && $("#gradeSectionDropdownTree").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id: 1, text: "Select All", expanded: true, items: [
                    { id: 2, text: "01" },
                    { id: 3, text: "02" },
                    { id: 4, text: "03" },
                    { id: 5, text: "04", expanded: true, items: [
                            { id: 6, text: "A" },
                            { id: 7, text: "B" },
                            { id: 8, text: "C" },
                        ]
                    }
                ]
            },
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.DataTable && $('#groupSendEmailData').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.DataTable && $('#olympiadTableData').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.DataTable && $('#manageNewsletterTemplateTableData').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.DataTable && $('#excelUploadEmailTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "bPaginate" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        }
    });

    $.fn.kendoDropDownTree && $("#studentListDropdownTree").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id: 1, text: " All Selected", expanded: true, items: [
                    { id: 2, text: "John" },
                    { id: 3, text: "Prema" },
                    { id: 4, text: "Sam" },
                    { id: 5, text: "Milli" },
                    { id: 6, text: "Katrina" },
                ]
            },
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.datetimepicker && $("#Emailtimepicker").datetimepicker({
        format: "LT",
        widgetPositioning: {
            horizontal: 'left',
            vertical: 'bottom'
        },
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });

    $('.send_email_select').on("click",function(){
        if(!$('#scheduleMailModal').hasClass('Email_modal')){
            $('#scheduleMailModal').addClass('Email_modal')
        }
    })
});

$(function() {
    $.fn.wysibb && $("#emailEditor,#emailEditorPrimary,#emailEditorSecondary").wysibb();
});

  // Time Picker
  $(function() {
      $.fn.datetimepicker && $("#startTimeControl").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });
      $.fn.datetimepicker && $("#endTimeControl").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });
});



$(document).ready(function () {
    // Send Email radio control
    $('input[type="radio"]').change(function(){
        if($("#usingGroupRadio:checked").length){
            $('.group-details-container').show();
            $('.upload-excel-container').hide();
        }
        if($("#excelUploadRadio:checked").length){
            $('.upload-excel-container').show();
            $('.group-details-container').hide();
        }

        //  Group Type Radio control for showing Addon form

        if($("#newGroupRadio:checked").length){
            $('.newGroupForm').show();
            $('.addONGroupForm').hide();
        }
        if($("#addOnRadio:checked").length){
            $('.addONGroupForm').show();
            $('.newGroupForm').hide();
        }
    });
    $('.upload-excel-container').hide();
    $('.addONGroupForm').hide();
});

$(document).ready(function () {
    // Change here for gallery list view/grid view:

  // Show/hide gallery menu
    $('.message-gallery-container .menu').on('click', function () {
        $(".menu-options").toggle();
    });

    $('document').on('click', function () {
        $(".message-gallery-container .menu-options").hide();
    });

// gallery list view/grid view local storage:
    var gallery_view = localStorage && localStorage.getItem('gallery-view') || 'gallery-view';
    var grid_view = document.getElementById('gallery-grid-view');
    var list_view = document.getElementById('gallery-list-view');

    if(gallery_view == "list"){
        list_view.style.display = "block";
        grid_view.style.display = "none";
    }
    else if(gallery_view == "grid"){
        grid_view.style.display = "block";
        list_view.style.display = "none";
    }
    else {
        list_view.style.display = "none";
        grid_view.style.display = "block";
    }

    $('#gallery-list-btn').on('click', function () {
            localStorage.setItem('gallery-view', 'list');
            if (list_view.style.display === "none") {
                list_view.style.display = "block";
                grid_view.style.display = "none";
            }

    });
    $('#gallery-grid-btn').on('click', function () {
        localStorage.setItem('gallery-view', 'grid');
        if (grid_view.style.display === "none") {
            grid_view.style.display = "block";
            list_view.style.display = "none";
        }
        
    });

    if(localStorage.getItem('gallery-view') == 'list') {
        $('#gallery-list-view .current-view').addClass('list_active');
    } else {
        $('#gallery-list-view .current-view').removeClass('list_active');
    }

});
