$(document).ready(function() {

    //dropdown-tree for manage-olympiads-->>
    $("#gradeAndSection").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        // filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Select all", expanded: true, items: [
                    { id: 2, text: "01" },
                    { id: 3, text: "02" },
                    { id: 4, text: "03"},
                    { id: 5, text: "04", expanded: true, items: [
                            {id:6, text: "A"},
                            {id:7, text: "B"}
                        ]
                    }
                ]
            }
        ]
    });
   $("#folderPermissionTree").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Suraj sinha"
            },
            {
                id:1, text: "Pankaj"
            },
            {
                id:1, text: "Rohit"
            },
            {
                id:1, text: "Anurag"
            }
        ],
        enable: true  // for disabled language dropdown
    });
    $("#folderParentPermissionTree").kendoDropDownTree({
        placeholder: "Select ...",
        checkboxes: {
            checkChildren: true
        },
        // filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Select all", expanded: true, items: [
                    { id: 2, text: "01" },
                    { id: 3, text: "02" },
                    { id: 4, text: "03"},
                    { id: 5, text: "04", expanded: true, items: [
                            {id:6, text: "A"},
                            {id:7, text: "B"}
                        ]
                    }
                ]
            }
        ]
    });
});