$(document).ready(function(){
  $('.remember-me-text').click(function(){
    $(this).toggleClass('checked');
  })
})