$(document).ready(function() {
    $.fn.DataTable && $('#regularTripsTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search Trip, Driver, Conductor"
        },
    });

    $.fn.DataTable && $('#logReportTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search..."
        },
    });

    $.fn.DataTable && $('#messageTemplateTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search Sl No or SMS Text"
        },
        bPaginate: false
    });

    $.fn.DataTable && $('#tab1-transportStudentsTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search Student Name or ID"
        },
    });

    $.fn.DataTable && $('#tab2-nonTransportStudentsTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search Student Name or ID"
        },
    });

    $.fn.DataTable && $('#tab3-allRequestsTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search Student Name or ID"
        },
        "bPaginate": false
    });

    $.fn.datetimepicker && $("#timepicker, #timepicker1, #timepicker2, #timepicker3, #timepicker4").datetimepicker({
        format: "LT",
        allowInputToggle : true,
        icons: {
            up: "fa fa-chevron-up",
            down: "fa fa-chevron-down"
        }
    });

    $.fn.DataTable && $('#addPickupTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength":10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search "
        },
        bPaginate: false
    });

    $.fn.DataTable && $('#busAreasTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength":11,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search "
        },
        bPaginate: true
    });


    $('#all-view-2').hide();
    $('#all-view-3').hide();
    $('#drop-delete').hide();
    $('#selected-view-2').hide();

    //Page Change on CTAs
    $('#view1-empty-search').on("focus", function () {
        $('#all-view-2').show();
        $('#all-view-1').hide();
        $('#selected-view-1').hide();
        $('#selected-view-2').show();
    });
    $('#view1-search').on("click", function () {
        $('#all-view-2').show();
        $('#all-view-1').hide();
        $('#selected-view-1').hide();
        $('#selected-view-2').show();
    });

    $('#view3-empty-search').on("focus", function () {
        $('#all-view-2').show();
        $('#all-view-1').hide();
        $('#all-view-3').hide();
    });

    $('#view3-search').on("click", function () {
        $('#all-view-2').show();
        $('#all-view-1').hide();
        $('#all-view-3').hide();
    });

    $('#item-1, #item-2, #item-3, #item-4').on("click", function () {
        $('#all-view-3').show();
        $('#all-view-2').hide();
        $('#all-view-1').hide();
    });

    $('#search-close-icon').on("click", function () {
        $('#all-view-3').show();
        $('#all-view-2').hide();
    });

//    Student log report contact details
    $('#student-contact-details-1').hide();
    $('#student-contact-details-2').hide();

    $( "#student-contact-cta-1" ).hover(function() {
        $('#student-contact-details-1').show();
    }, function() {
            $('#student-contact-details-1').hide();
    });

    $( "#student-contact-cta-2" ).hover(function() {
        $('#student-contact-details-2').show();
    }, function() {
        $('#student-contact-details-2').hide();
    });

    //Student transport service - tab1 action
    $('#r1-actions').hide();

    $('#r1-select').on('click',function () {
        $('#r1-actions').toggle();
    });

    // transport new-request-search
    $('#transpoRtequestSearchResult').hide();
    $("#transpoRtequestSearch").on('click', function (){
        $('#transpoRtequestSearchResult').show();
    });

    //expand all --->
    function expandCollapseAllAccordion () {
        let acc = document.getElementsByClassName("custom-accordion");
        let i;

        for (i = 0; i < acc.length; i++) {
            acc[i].click({abc : true}, function() {
                this.classList.addClass("active");
                let panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.scrollHeight !== 0 ?
                        panel.style.maxHeight = panel.scrollHeight + "px" :
                        panel.style.maxHeight = "fit-content";
                }
            });
        }
        acc[0].click();
    }

    $('#collapseAllAccordion').hide();

    $('#expandAllAccordion').on("click", function () {
        expandCollapseAllAccordion();
        $('#collapseAllAccordion').show();
        $('#expandAllAccordion').hide();
    });

    $('#collapseAllAccordion').on("click", function () {
        expandCollapseAllAccordion();
        $('#expandAllAccordion').show();
        $('#collapseAllAccordion').hide();
    });
//------------------

    $('#tab2-transport-services').on('click',function(){
        $('.page-actions').addClass('hide');
        
    })
    $('#tab1-transport-services').on('click',function(){
        $('.page-actions').removeClass('hide');
        
    })
    $('#tab3-transport-services').on('click',function(){
        $('.page-actions').removeClass('hide');
        
    })


});

$( function() {
    $.fn.sortable && $("#selectedListDraggable").sortable();
    $.fn.disableSelection && $("#selectedListDraggable").disableSelection();
});



