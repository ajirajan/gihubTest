$(document).ready(function () {
    // BSU ID Name Search
    $('#bsuIDNameSearch').keyup(function () {
        $('.search-items').slideDown('fast');
    });

    $('#bsuIDNameSearch').focusout(function () {
        $('.search-items').slideUp('fast');
    });

    $.fn.kendoDropDownTree && $("#departmentTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "All"
            },
            {
                id:2, text: "Accounting"
            },
            {
                id:3, text: "Academic Supervisor"
            },
            {
                id:4, text: "Academic Plus"
            },
            {
                id:5, text: "Art Supervisor"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#designationTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Department Head"
            },
            {
                id:2, text: "Junior Teacher"
            },
            {
                id:3, text: "Senior Teacher"
            },
            {
                id:4, text: "Maintenance Staff"
            },
            {
                id:5, text: "Security Guard"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#staffCategoryTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Manager"
            },
            {
                id:2, text: "Associate Manager"
            },
            {
                id:3, text: "Admin"
            },
            {
                id:4, text: "Faculty"
            },
            {
                id:5, text: "Department Head"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#staffTypeTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Permanent"
            },
            {
                id:2, text: "Temporary"
            },
            {
                id:3, text: "Contract"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#employeeStatusTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Experienced"
            },
            {
                id:2, text: "Temporary"
            },
            {
                id:3, text: "Trainee"
            },
            {
                id:4, text: "Active"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#localOverseasTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Local Overseas - 1"
            },
            {
                id:2, text: "Local Overseas - 2"
            },
            {
                id:3, text: "Local Overseas - 3"
            },
            {
                id:4, text: "Local Overseas - 4"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#ticketClassTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Business Class"
            },
            {
                id:2, text: "Economy"
            },
            {
                id:3, text: "First Class"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#airTicketEligibilityTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Child"
            },
            {
                id:2, text: "Ladies"
            },
            {
                id:3, text: "Citizen"
            },
            {
                id:4, text: "Senior Citizen"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#transportTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Car"
            },
            {
                id:2, text: "Delux Bus"
            },
            {
                id:3, text: "Private Vehicle"
            },
            {
                id:4, text: "AC Train"
            },
            {
                id:5, text: "Metro Train"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#accommodationTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "1 Bedroom"
            },
            {
                id:2, text: "2 Bedroom"
            },
            {
                id:3, text: "VIP Bedroom"
            },
            {
                id:4, text: "AC Bedroom"
            },
            {
                id:4, text: "Non AC Bedroom"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#accommodationTypeTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Normal"
            },
            {
                id:2, text: "VIP"
            },
            {
                id:3, text: "Special"
            },
            {
                id:4, text: "Hotel"
            },
            {
                id:5, text: "Restaurants"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    $.fn.kendoDropDownTree && $("#bachelorSharingTreeDropdown").kendoDropDownTree({
        placeholder: "Select",
        checkboxes: {
            checkChildren: true
        },
        filter: "startswith",
        checkAll: false,
        autoClose: false,
        dataSource: [
            {
                id:1, text: "Double Sharing"
            },
            {
                id:2, text: "Triple Sharing"
            },
            {
                id:3, text: "Hall"
            },
            {
                id:4, text: "Shared Master"
            },
            {
                id:5, text: "Individual"
            }
        ],
        enable: true  // for disabled language dropdown
    });

    function expandCollapseAllAccordion () {
        let acc = document.getElementsByClassName("custom-accordion");
        let i;

        for (i = 0; i < acc.length; i++) {
            acc[i].click({abc : true}, function() {
                this.classList.addClass("active");
                let panel = this.nextElementSibling;
                if (panel.style.maxHeight) {
                    panel.style.maxHeight = null;
                } else {
                    panel.scrollHeight !== 0 ?
                        panel.style.maxHeight = panel.scrollHeight + "px" :
                        panel.style.maxHeight = "fit-content";
                }
            });
        }
        acc[0].click();
    }

    $('#collapseAllAccordion').hide();

    $('#expandAllAccordion').on("click", function () {
        expandCollapseAllAccordion();
        $('#collapseAllAccordion').show();
        $('#expandAllAccordion').hide();
    });

    $('#collapseAllAccordion').on("click", function () {
        expandCollapseAllAccordion();
        $('#expandAllAccordion').show();
        $('#collapseAllAccordion').hide();
    });

    // select all fields of table.
    $('#selectAllFields').bind('click', function() {
        if(this.checked) {
            $(':checkbox').each(function() {
                this.checked = true;
            });
        } else {
            $(':checkbox').each(function() {
                this.checked = false;
            });
        }
    });

    $('table .custom-checkbox input:checkbox').change(function () {
        if($(this).prop("checked") === false){
            $('#selectAllFields').prop("indeterminate", true);
        }

        if($(this).prop("checked") === true){
            $('#selectAllFields').prop("indeterminate", true);
        }
    });

//    check all checkbox from table header checkbox

    $('#basicInformationAllRows').click(function (e) {
        $(this).closest('table').find('td .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#basicInformationTable td .custom-checkbox input:checkbox').click(function(){
        $('#basicInformationAllRows').prop("indeterminate", true);
        if($(this).prop("checked") === false){
            $('#basicInformationAllRows').prop("indeterminate", true);
        }
    });

    $('#passportAllRows').click(function (e) {
        $(this).closest('table').find('td .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#passportVisaInfoTable td .custom-checkbox input:checkbox').click(function(){
        if($(this).prop("checked") === false){
            $('#passportAllRows').prop('checked', false);
        }
    });

    $('#EmploymentAllRows').click(function (e) {
        $(this).closest('table').find('td .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#employmentProfessionTable td .custom-checkbox input:checkbox').click(function(){
        if($(this).prop("checked") === false){
            $('#EmploymentAllRows').prop('checked', false);
        }
    });

    $('#otherAllRows').click(function (e) {
        $(this).closest('table').find('td .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#otherInfoTable td .custom-checkbox input:checkbox').click(function(){
        if($(this).prop("checked") === false){
            $('#otherAllRows').prop('checked', false);
        }
    });

    $.fn.DataTable &&  $('#employeeDetails').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftilpr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            sLengthMenu: "_MENU_",
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        },
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
});

    $.fn.DataTable &&  $('#employeeResignationList').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });

//    Employee number and name search
    $('#empNumberNameSearch').keyup(function () {
        $('.search-items').slideDown('fast');
    });

    $('#empNumberNameSearch').focusout(function () {
        $('.search-items').slideUp('fast');
    });

    $.fn.DataTable &&  $('#employeeAttendanceList').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });

    var totalAttendanceCorrectionRecords = $('#employeeAttendanceList').dataTable();
    $('#employeeAttendanceListCount').text("Showing " +totalAttendanceCorrectionRecords.fnGetData().length+ " records");

    // bulk actions control functionality
    $('.bulk-actions-control').hide();
    $('#employeeAttendanceList tr td:first-child .custom-checkbox input:checkbox').click(function(){
        if($(this).is(":checked")) {
            $(".bulk-actions-control").show(500);
        } else {
            $(".bulk-actions-control").hide(500);
        }
    });

    $('.add-employee-resignation').hide();
    $('#addEmployeeResignation').on("click", function () {
        $('.add-employee-resignation').show();
        $('.employee-resignation-list').hide();
    });

    $('#saveResignationData').click(function () {
        $('.add-employee-resignation').hide();
        $('.employee-resignation-list').show();
    });

    $.fn.DataTable &&  $('#attendanceCorrectionTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "paging": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search",
        },
    });

    var totalTableRecords = $('#attendanceCorrectionTable').dataTable();
    $('#attendanceCorrectionListCount').text("Showing " +totalTableRecords.fnGetData().length+ " records");

    $.fn.DataTable &&  $('#AttendanceFinalApprovalTable').DataTable({
        "searching": false,
        "info": false,
        "dom": 'ftilpr',
        "bSort" : false,
        "pageLength": 10,
        language: {
            paginate: {
                next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>',
                previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
                    '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
                    '</svg>\n</i>'
            },
            search: "_INPUT_",
            searchPlaceholder: "Search"
        },
        // scrollX: true,
        // scrollCollapse: true,
        fixedColumns:   {
            leftColumns: 3
        },
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
    });

    $.fn.DataTable &&  $('#finalSettlementTable').DataTable({
        "searching": true,
        "info": false,
        "dom": 'ftipr',
        "bSort" : false,
        "bPaginate": false,
        language: {
            search: "_INPUT_",
            searchPlaceholder: "Search"
        },
        "columnDefs": [
            {
                "width": "10%",
                "targets": 1
            },
            {
                "width": "150px",
                "targets": 10
            }
        ],
        "scrollX": true, // scrollX: true // for showing horizontal scroll, but it will specify when number of columns more than view
        "sScrollXInner": "100%",
    });

    $('#employeeLeaveUpdateAllRows').click(function (e) {
        $(this).closest('table').find('td:first-child .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#employeeLeaveUpdateTable td:first-child .custom-checkbox input:checkbox').click(function(){
        $('#employeeLeaveUpdateAllRows').prop("indeterminate", true);
        if($(this).prop("checked") === false){
            $('#employeeLeaveUpdateAllRows').prop("indeterminate", true);
        }
    });

    $('#employeeAttendanceSelectAll').click(function (e) {
        $(this).closest('table').find('td:first-child .custom-checkbox input:checkbox').prop('checked', this.checked);
    });

    $('#employeeAttendanceList td:first-child .custom-checkbox input:checkbox').click(function(){
        $('#employeeAttendanceSelectAll').prop("indeterminate", true);
        if($(this).prop("checked") === false){
            $('#employeeAttendanceSelectAll').prop("indeterminate", true);
        }
    });
});

$(function () {
    $('.confirmation-parameter-selection').hide();
    $('#confirmSelectionBtn').hide();
    $('#confirmParameterSelection .button').on("click", function () {
        $('.confirmation-parameter-selection').show();
        $(this).hide();
        $('#confirmSelectionBtn').show();
        $('#exportBtn').hide();
    })
});

$(function () {
    $('.final-settlement-details').hide();
    $('#finalSettlementDetails').on("click", function () {
        $('.final-settlement-details').show();
        $('.final-settlement-listing').hide();
    });
});
