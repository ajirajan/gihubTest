let WindowWidth = $(window).width();
var MobileWidth = 768;

// polyfill

if (!String.prototype.endsWith) {
  String.prototype.endsWith = function (search, this_len) {
    if (this_len === undefined || this_len > this.length) {
      this_len = this.length;
    }
    return this.substring(this_len - search.length, this_len) === search;
  };
}

if (!Array.prototype.filter) {
  Array.prototype.filter = function (func, thisArg) {
    'use strict';
    if (!((typeof func === 'Function' || typeof func === 'function') && this))
      throw new TypeError();

    var len = this.length >>> 0,
      res = new Array(len), // preallocate array
      t = this, c = 0, i = -1;

    var kValue;
    if (thisArg === undefined) {
      while (++i !== len) {
        // checks to see if the key was set
        if (i in this) {
          kValue = t[i]; // in case t is changed in callback
          if (func(t[i], i, t)) {
            res[c++] = kValue;
          }
        }
      }
    }
    else {
      while (++i !== len) {
        // checks to see if the key was set
        if (i in this) {
          kValue = t[i];
          if (func.call(thisArg, t[i], i, t)) {
            res[c++] = kValue;
          }
        }
      }
    }

    res.length = c; // shrink down array to proper size
    return res;
  };
}

// End of polyfill

function isInArray(date, dates) { // this function is used in initMiniCalendar()
  for (var idx = 0, length = dates.length; idx < length; idx++) {
    var d = dates[idx];
    if (date.getFullYear() == d.getFullYear() &&
      date.getMonth() == d.getMonth() &&
      date.getDate() == d.getDate()) {
      return true;
    }
  }
  return false;
}

var Phoenix = function () {
  var self = this;
  self.init_when_ready = function () {
    self.loadSettings();
    self.handleFontSize();
    self.handleLanguage();

    // Design Functions
    self.showLoader();
    self.createPieChart();
    self.createGaugeChart();
    self.createDonutChart();
    self.createBarChart();

    // Init Functions
    self.init_sidebar_popups();
    self.initStudentSearchTable();
    self.initBarcodes();
    self.initMiniCalendar();
    self.initFullCalendar();
    self.updateOrganizationRowAfterWidth();

    // Scroll Functions

    // Event Functions
    self.toggleTabs();
    // self.showLoaderInTabs();
    self.toggleSidebarMenu();
    self.toggleProfileOptions();
    self.toggleSearchListing();
    self.updateSettings();
    self.toggleHiddenFilters();
    self.handleStudentSearchTableCheckboxes();
    self.handleMultipleTabContents();
    self.toggleProfileSnapshot();
    self.handleSearchField();
    self.toggleMorePaymentMethods();
    self.toggleTable();
    self.handleTodoList();
    self.toggleSendAction();
    self.handleDetailsPopover();
    self.handleVerticalSteps();
    self.handleToolTip();
    self.handleProgressSteps();
    self.handleToggleEvents();
    self.handleQuickLinksCarousel();
    self.handleDashboardDragnDrop();
    self.handleConfigSearch();
  };

  self.init_after_load = function () {
    self.hideLoader();
  };

  self.init_on_resize = function () {
    WindowWidth = $(window).width();
    self.init_sidebar_popups();
    self.resizeGraphs();
  };

  self.init_on_scroll = function () {

  };

  self.toggleTabs = function () {
    $(document).on('click', '.tab-button', function () {
      $('.tab-button').removeClass('selected');
      $(this).addClass('selected');

      var target = $(this).attr('data-target');

      if ($('body').hasClass('top_bar') && WindowWidth > MobileWidth) {
        $('.sidebar-nav-items-wrapper').removeClass('show');
        $(target).addClass('show');
      }
      else {
        $('.sidebar-nav-items-wrapper').hide();
        $(target).fadeIn();
      }
    });

    if ($('body').hasClass('top_bar') && WindowWidth > MobileWidth) {
      $(document).on('click', '.sidebar-tabs', function () {
        $('.sidebar-tabs').toggleClass('expand');
      });

      $(document).on('click', function (e) {
        var container = $('.sidebar-tabs');
        if (!container.is(e.target) && container.has(e.target).length === 0) {
          $('.sidebar-tabs').removeClass('expand');
        }
      });
    }
  };

  self.showLoader = function () {
    $('.phoenix-loader').show();
  };

  self.hideLoader = function () {
    $('.phoenix-loader').fadeOut('fast');
  };

  self.showLoaderInTabs = function () {
    $(document).on('click', '.tab-button', function () {
      $('.phoenix-loader').show();
      setTimeout(function () {
        $('.phoenix-loader').fadeOut('fast');
      }, 600);
    });
  };

  self.init_sidebar_popups = function () {
    $('.nav_sub_menu li, .sub_menu_without_li').each(function () {
      var item = $(this);
      var navOptions = item.find('.nav-item-popover');

      if (navOptions.length) {
        item.popover('dispose');
        item.popover({
          animation: true,
          trigger: 'manual',
          html: true,
          container: 'body',
          placement: $('body').hasClass('top_bar') ? 'bottom' : 'right',
          content: navOptions.find('.popover-content-body').length ? navOptions.find('.popover-content-body').clone() : '',
          boundary: 'viewport',
          title: WindowWidth <= MobileWidth ? navOptions.find('.popover-content-header').clone() : '',
        }).click(function (evt) {
          // REMOVING EXISTING POPOVER
          var existingPopoverId = $('.popover').attr('id');
          if (existingPopoverId) {
            $("[aria-describedby=" + existingPopoverId + "]").popover('hide').toggleClass('active');
          }

          item.popover('toggle');
          item.toggleClass('active');

          evt.stopPropagation();
        });
        $('body').on('click', function (e) {
          item.popover('hide');
          item.removeClass('active');
        });
      }

    })
  };

  self.createPieChart = function () {
    if (!$("#pie-chart").length) {
      return;
    }
    $("#pie-chart").kendoChart({
      theme: 'bootstrap',
      title: {
        visible: false,
        position: "bottom",
        text: "Total Students \n 2250",
      },
      legend: {
        visible: false,
      },
      chartArea: {
        background: "",
        height: 120,
      },
      seriesDefaults: {

      },
      series: [{
        type: "pie",
        data: [{
          category: "Male",
          value: 1688,
          color: "#29A9F8"
        }, {
          category: "Female",
          value: 562,
          color: "#00FCD5"
        }],
        padding: 0
      }],
      tooltip: {
        visible: true,
        // format: "{0}{3}"
      }
    });
  };

  self.createGaugeChart = function () {
    if (!$("#gauge-chart").length) {
      return;
    }
    $("#gauge-chart").kendoRadialGauge({
      pointer: {
        value: 0,
        color: 'transparent',
      },
      gaugeArea: {
        height: 120,
      },
      scale: {
        majorTicks: {
          visible: false,
        },
        rangePlaceholderColor: 'transparent',
        rangeSize: 15,
        minorUnit: 20,
        startAngle: 0,
        endAngle: 180,
        max: 100,
        labels: {
          visible: false,
          position: "inside"
        },
        ranges: [
          {
            from: 0,
            to: 19,
            color: "#D8DBE3"
          }, {
            from: 20,
            to: 39,
            color: "#F55555"
          }, {
            from: 40,
            to: 59,
            color: "#FFA145"
          }, {
            from: 60,
            to: 79,
            color: "#FED751"
          }, {
            from: 80,
            to: 100,
            color: "#ABE154"
          }
        ]
      }
    });
  };

  self.createDonutChart = function () {
    var donutChartRedConfig = {
      legend: {
        visible: false
      },
      chartArea: {
        height: 120,
        width: 120,
      },
      seriesDefaults: {
        type: "donut",
        startAngle: 90,
        holeSize: 40,
        size: 15,
      },
      series: [
        {
          name: "Teaching Staff",
          data: [{
            value: 64,
            color: "#F55555"
          }, {
            value: 36,
            color: "#DFE3EF"
          },],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
    };
    self._createDonutChart('#donut-chart-red', donutChartRedConfig)

    var donutChartOrangeConfig = {
      legend: {
        visible: false
      },
      chartArea: {
        height: 120,
        width: 120,
      },
      seriesDefaults: {
        type: "donut",
        startAngle: 90,
        holeSize: 40,
        size: 15,
      },
      series: [
        {
          name: "Teaching Staff",
          data: [{
            value: 71,
            color: "#FFA145"
          }, {
            value: 29,
            color: "#DFE3EF"
          },],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
    };
    self._createDonutChart('#donut-chart-orange', donutChartOrangeConfig)

    var donutChartYellowConfig = {
      legend: {
        visible: false
      },
      chartArea: {
        height: 120,
        width: 120,
      },
      seriesDefaults: {
        type: "donut",
        startAngle: 90,
        holeSize: 40,
        size: 15,
      },
      series: [
        {
          name: "Teaching Staff",
          data: [{
            value: 82,
            color: "#FED751"
          }, {
            value: 18,
            color: "#DFE3EF"
          },],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
    };
    self._createDonutChart('#donut-chart-yellow', donutChartYellowConfig);

    var donutChartGreenConfig = {
      legend: {
        visible: false
      },
      chartArea: {
        height: 120,
        width: 120,
      },
      seriesDefaults: {
        type: "donut",
        startAngle: 90,
        holeSize: 40,
        size: 15,
      },
      series: [
        {
          name: "Teaching Staff",
          data: [{
            value: 91,
            color: "#ACE254"
          }, {
            value: 9,
            color: "#DFE3EF"
          },],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
    };
    self._createDonutChart('#donut-chart-green', donutChartGreenConfig);

    var feeAgeingChartConfig = {
      title: {
        text: '8194.00',
        font: '14px MontserratMedium',
        color: '#222734',
        position: 'bottom',
        margin: {
          top: -15
        },
      },
      series: [
        {
          name: "Fee Ageing Chart",
          data: [
            {
              value: 71,
              color: "#ACE254",
            }, {
              value: 29,
              color: "#fed751"
            }
          ],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
      legend: {
        visible: false
      },
      chartArea: {
        height: 250,
      },
      seriesDefaults: {
        type: "donut",
        // startAngle: 90,
        // holeSize: 40,
        size: 35,
      },
      tooltip: {
        visible: true,
        template: "#= value #%"
      },
    };
    self._createDonutChart('#fee-ageing-chart', feeAgeingChartConfig);

    var leaveBalanceDonutChartConfig = {
      title: {
        text: '',
      },
      series: [
        {
          name: "",
          data: [
            {
              value: 71,
              color: "#abe154",
            },
            {
              value: 29,
              color: "#fed751"
            },
            {
              value: 10,
              color: "#29A9F8"
            }
          ],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
      legend: {
        visible: false
      },
      chartArea: {
        height: 250,
      },
      seriesDefaults: {
        type: "donut",
        size: 35,
      },
    };
    self._createDonutChart('#leave-balance-donut-chart', leaveBalanceDonutChartConfig);

    var essDashboardLeaveBalanceDonutChartConfig = {
      title: {
        text: '',
      },
      series: [
        {
          name: "",
          data: [
            {
              value: 71,
              color: "#abe154",
            },
            {
              value: 29,
              color: "#fed751"
            },
            {
              value: 35,
              color: "#ffa145"
            },
            {
              value: 10,
              color: "#29A9F8"
            }
          ],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
      legend: {
        visible: false
      },
      chartArea: {
        height: 250,
      },
      seriesDefaults: {
        type: "donut",
        size: 35,
      },
    };
    self._createDonutChart('#ess-dashboard-leave-balance-donut-chart', essDashboardLeaveBalanceDonutChartConfig);

    var engagementLogsDonutChartConfig = {
      title: {
        text: '',
      },
      series: [
        {
          name: "",
          data: [
            {
              value: 0,
              color: "#f55555",
            },
            {
              value: 60,
              color: "#abe154"
            },
            {
              value: 40,
              color: "#fed751"
            }
          ],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
      legend: {
        visible: false
      },
      chartArea: {
        height: 250,
      },
      seriesDefaults: {
        type: "donut",
        size: 35,
      },
      tooltip: {
        visible: true,
        template: "#= value #%"
      },
    };
    self._createDonutChart('#engagement-logs-donut-chart', engagementLogsDonutChartConfig);

    var categoryWiseCountDonutChartConfig = {
      title: {
        text: '',
      },
      series: [
        {
          name: "",
          data: [
            {
              value: 5,
              color: "#50c33b",
            },
            {
              value: 25,
              color: "#f48432"
            },
            {
              value: 40,
              color: "#45b6e0"
            },
            {
              value: 25,
              color: "#6675ea"
            }
          ],
          labels: {
            visible: false,
            background: "transparent",
            position: "outsideEnd",
            template: "#= category #: \n #= value#%"
          },
          padding: 0,
        }
      ],
      legend: {
        visible: false
      },
      chartArea: {
        height: 250,
      },
      seriesDefaults: {
        type: "donut",
        size: 35,
      },
      tooltip: {
        visible: true,
        template: "#= value #"
      },
    };
    self._createDonutChart('#category-wise-count-donut-chart', categoryWiseCountDonutChartConfig);
  };

  self._createDonutChart = function (id, config) {
    if (!$(id).length) {
      return;
    }

    $(id).kendoChart(
      $.extend(
        config,
        {
          theme: 'material',
          // tooltip: {
          //   visible: false,
          //   // template: "#= category # (#= series.name #): #= value #%"
          //   template: "#= value #%"
          // },
        }
      )
    );
  };

  self.createBarChart = function () {
    var achievementStatisticsChartConfig = {
      seriesDefaults: {
        type: "column",
        // stack: true,
        labels: {
          visible: true,
          background: "transparent",
          color: '#90B9E8',
          font: '16px MontserratBold'
        }
      },
      series: [
        {
          name: "",
          data: [5, 6, 11, 9, 2, 10],
          color: '#90B9E8',
        }
      ],
      categoryAxis: {
        categories: ["Sun", "Mon", "Tue", "Wed", "Thurs", "Fri"],
        majorGridLines: {
          visible: false
        }
      },
    };
    self._createBarChart('#achievement-statistics-chart', achievementStatisticsChartConfig);

    var attendanceByMonthChartConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        labels: {
          visible: true,
          background: "transparent",
          color: '#f88530',
          font: '16px MontserratBold'
        }
      },
      series: [
        {
          name: "",
          data: [5, 6, 11, 9, 2, 10, 5, 6, 11, 9, 2, 10],
          color: '#f88530',
        }
      ],
      categoryAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#attendance-by-month-chart', attendanceByMonthChartConfig);

    var weeklyAbsentPatternConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        labels: {
          visible: true,
          background: "transparent",
          color: '#90b9e8',
          font: '16px MontserratBold'
        }
      },
      series: [
        {
          name: "",
          data: [5, 6, 11, 9, 2, 10],
          color: '#90b9e8',
        }
      ],
      categoryAxis: {
        categories: ["Sun", "Mon", "Tue", "Wed", "Thurs", "Fri"],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#weekly-absent-pattern-chart', weeklyAbsentPatternConfig);

    var weeklyLatePatternConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        labels: {
          visible: true,
          background: "transparent",
          color: '#4b366b',
          font: '16px MontserratBold'
        }
      },
      series: [
        {
          name: "",
          data: [5, 6, 11, 9, 2, 10],
          color: '#4b366b',
        }
      ],
      categoryAxis: {
        categories: ["Sun", "Mon", "Tue", "Wed", "Thurs", "Fri"],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#weekly-late-pattern-chart', weeklyLatePatternConfig);

    var curriculumChartConfig = {
      title: {
        text: 'Student Performance',
        font: '14px MontserratMedium',
        color: '#222734',
        margin: {
          bottom: 10,
        },
      },
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        labels: {
          visible: true,
          background: "transparent",
          color: '#4b366b',
          font: '9px MontserratRegular'
        },
        gap: 5
      },
      series: [
        {
          name: "",
          data: [25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25, 25],
          color: '#ffa145',
        },
        {
          name: "",
          data: [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
          color: '#27a9e0',
        },
        {
          name: "",
          data: [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10],
          color: '#8dc24c',
        },
        {
          name: "",
          data: [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
          color: '#de7324',
        },
      ],
      categoryAxis: {
        categories: ["KG1", "KG2", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        majorGridLines: {
          visible: false
        }
      },
      legend: {
        position: 'right',
        labels: {
          font: "10px MontserratMedium",
          color: "#222734",
          margin: {
            top: 10,
            bottom: 10,
          },
        }
      }
    }
    self._createBarChart('#curriculum-chart', curriculumChartConfig);

    var feeSummaryChartConfig = {
      title: {
        text: 'Fee Paid By Month',
        font: '14px MontserratMedium',
        color: '#222734',
        align: 'left',
        margin: {
          left: -8,
          bottom: 20,
        },
      },

      chartArea: {
        height: 300,
      },

      seriesDefaults: {
        type: "column",
        labels: {
          visible: true,
          background: "transparent",
          // color: '#4b366b',
          font: '12px MontserratMedium'
        }
      },

      series: [
        {
          name: "",
          data: [500, 623, 131, 439, 102, 100, 423],
          color: '#71d8c0',
        }
      ],

      categoryAxis: {
        categories: ["Sep-2019", "Oct-2019", "Nov-2019", "Dec-2019", "Jan-2020", "Feb-2020", "Mar-2020"],
        majorGridLines: {
          visible: false
        },
      },

      valueAxis: {
        labels: {
          color: '#69738d',
        },
      }
    };
    self._createBarChart('#fee-summary-chart', feeSummaryChartConfig);

    var leaveBalanceConfig = {
      title: {
        text: '',
      },
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
      },
      series: [
        {
          name: "",
          data: [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
          color: '#ffa429',
        },
        {
          name: "",
          data: [10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10],
          color: '#29A9F8',
        },
        {
          name: "",
          data: [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
          color: '#fed751',
        },
      ],
      categoryAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        majorGridLines: {
          visible: false
        }
      },
      legend: {
        visible: false,
      }
    }
    self._createBarChart('#leave-balance-chart', leaveBalanceConfig);

    var areaOfDiscussionChartConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        stack: true,
        labels: {
          // visible: true,
          background: "transparent",
          color: '#71d8c0',
          font: '16px MontserratBold'
        },
        gap: 0.9,
      },
      series: [
        {
          name: "",
          data: [5, 6, 11, 9, 2, 10, 5],
          color: '#71d8c0',
        },
        {
          name: "",
          data: [2, 3, 7, 11, 5, 9, 2],
          color: '#42ad94',
        }
      ],
      categoryAxis: {
        categories: ["Financial", "Academic", "Counselling", "Services", "Well-Being", "Incidents", "Admission"],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#area-of-discussion-chart', areaOfDiscussionChartConfig);
    
    var followUpsChartConfig = {
      chartArea: {
        // height: 300,
      },
      seriesDefaults: {
        type: "column",
        stack: true,
        labels: {
          visible: true,
          background: "transparent",
          color: '#e17453',
          font: '16px MontserratBold'
        },
        gap: 0.5,
      },
      series: [
        {
          name: "",
          data: [80, 190, 10, 170],
          color: '#e17453',
        }
      ],
      categoryAxis: {
        categories: ["Closed", "Academic", "Counselling", "Services"],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#follow-ups-chart', followUpsChartConfig);
    

    var blackTooltip = {
      visible: true,
      background: 'black',
      font: "12px MontserratSemiBold",
      border: {
        width: 0,
      },
    }; 
    var engagementLogsChartConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "column",
        labels: {
          visible: false,
          background: "transparent",
          color: '#4b366b',
          font: '9px MontserratRegular'
        },
      },
      series: [
        {
          name: "",
          data: [10,10,5,10,10,5,10,12,10,4,10,4,10,25],
          color: '#90b9e8',
          // tooltip: blackTooltip,
        },
        {
          name: "",
          data: [6,15,16,13,8,14,9,16,5,17,16,12,7,25],
          color: '#6290c6',
          // tooltip: blackTooltip,
        },
        {
          name: "",
          data: [20,12,20,18,5,16,15,12,17,7,13,18,20,25],
          color: '#4475ad',
          // tooltip: blackTooltip,
        },
      ],
      categoryAxis: {
        categories: ["KG1", "KG2", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#engagement-logs-chart', engagementLogsChartConfig);

    var engagementLogsByDateChartConfig = {
      chartArea: {
        height: 300,
      },
      seriesDefaults: {
        type: "line",
        labels: {
          visible: false,
          background: "transparent",
          color: '#4b366b',
          font: '9px MontserratRegular'
        },
        line: {
          opacity: 0.3,
          width: 1,
        }
      },
      series: [
        {
          name: "",
          data: [],
          color: '#90b9e8',
          // tooltip: blackTooltip,
        },
        {
          name: "",
          data: [],
          color: '#6290c6',
          // tooltip: blackTooltip,
        },
        {
          name: "",
          data: [20,12,15,10,25,40,5,10,22,13,17,9,20,20],
          color: '#4475ad',
          // tooltip: blackTooltip,
        },
      ],
      categoryAxis: {
        categories: ["KG1", "KG2", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        majorGridLines: {
          visible: false
        }
      },
    }
    self._createBarChart('#engagement-logs-by-date-chart', engagementLogsByDateChartConfig);
  };

  self._createBarChart = function (id, config) {
    if (!$(id).length) {
      return;
    }
    $(id).kendoChart(
      $.extend(
        config,
        {
          theme: 'material',
          title: {
            text: ""
          },
          legend: {
            position: "bottom"
          },
          valueAxis: {
            line: {
              visible: false
            },
            majorGridLines: {
              dashType: "dash",
              color: '#e3e5ea',
            },
          },
          tooltip: {
            visible: true,
            format: "{0}"
          },
          axisDefaults: {
            labels: {
              font: '12px MontserratRegular',
              color: '#69738d',
            },
          },
        }
      )
    );
  };

  self.resizeGraphs = function () {
    $('#pie-chart').length && $('#pie-chart').data("kendoChart").resize();
    $(".donut-chart").length && $(".donut-chart").each(function () { $(this).data("kendoChart").resize(); });
    $(".bar-chart").length && $(".bar-chart").each(function () { $(this).data("kendoChart").resize(); });
    $("#gauge-chart").length && $("#gauge-chart").data("kendoRadialGauge").resize();
  };

  self.toggleSidebarMenu = function () {
    $('.menu_btn').on('click', function () {
      $('.menu_btn').toggleClass('open');
      $('.phoenix-sidebar').toggleClass('slide_out');
    })
  };

  self.toggleProfileOptions = function () {
    $('.phoenix-user-image').on('click', function () {
      $('.profile_options').slideToggle('fast');
    });
  };

  self.toggleSearchListing = function () {
    $('.phoenix-g-search-input').on('click', function () {
      $('.recent_search_listing').slideDown('fast');
    });

    $(document).on('click', function (e) {
      var container = $('.phoenix-g-search-input, .recent_search_listing');
      if (!container.is(e.target) && container.has(e.target).length === 0) {
        $('.recent_search_listing').slideUp('fast');
      }
    });

    $('.phoenix-g-search-input').on('keyup', function () {
      if ($('.phoenix-g-search-input').val()) {
        $('.recent_search_listing').addClass('search_list');
      }
      else {
        $('.recent_search_listing').removeClass('search_list');
      }
    });
  };

  self.loadSettings = function () {
    // Theme
    var theme = localStorage.getItem('phoenix-theme') || 'green-theme';
    $("input[value=" + theme + "]").click();
    $('body').attr('class', ($('body').attr('class') || "")
      .split(' ')
      .filter(function (x) { return !x.endsWith('-theme') })
      .join(' ')
    );
    $('body').addClass(theme);

    // Navigation
    var navPosition = localStorage.getItem('navPosition') || 'left';
    $("input[value=" + navPosition + "]").click();
    navPosition == 'top' && $('body').addClass('top_bar');
  };

  self.updateSettings = function () {
    $('#update-settings').on('click', function () {
      // Theme
      var theme = $('input[name="themeColor"]:checked').val() || 'green-theme';
      $('body').attr('class', ($('body').attr('class') || "")
        .split(' ')
        .filter(function (x) { return !x.endsWith('-theme') })
        .join(' ')
      );
      $('body').addClass(theme);

      // Top navigation
      var storedNavPosition = localStorage.getItem('navPosition') || 'left';
      var navPosition = $('input[name="navPosition"]:checked').val() || 'left';
      navPosition != storedNavPosition && location.reload();

      localStorage.setItem('phoenix-theme', theme);
      localStorage.setItem('navPosition', navPosition);
    });
  };

  self.handleLanguage = function () {
    var language = localStorage.getItem('language') || 'Eng';
    $('.lang_select select').val(language);

    $('.lang_select select').on('change', function () {
      language = $(this).val();
      localStorage.setItem('language', language || 'Eng');

      if (language === 'Ar') {
        $('body').addClass('arabic');
        $('#rtl-stylesheet').length
          ? $('#rtl-stylesheet').attr('disabled', false)
          : $("<link/>", {
            id: 'rtl-stylesheet',
            rel: "stylesheet",
            type: "text/css",
            href: "//cdn.rawgit.com/morteza/bootstrap-rtl/v3.3.4/dist/css/bootstrap-rtl.min.css"
          }).appendTo("head");

        $('.my-quick-links-container').scrollLeft($('.my-quick-links-container').width());
      }
      else {
        $('body').removeClass('arabic');
        $('#rtl-stylesheet').attr('disabled', true);
      }

      self.updateQuickLinkArrows();
    });
  };

  self.toggleHiddenFilters = function () {
    $('.show-filters').on('click', function () {
      $('.hidden-filters').slideDown('fast');
      $('.show-filters').hide();
      $('.hide-filters').show();
    });

    $('.hide-filters').on('click', function () {
      $('.hidden-filters').slideUp('fast');
      $('.show-filters').show();
      $('.hide-filters').hide();
    });

    // This should be removed
    $('.search-button').on('click', function () {
      $('#search-results').fadeToggle('fast');
    })
  };

  self.toggleTable = function () {
    $('.show-table').on('click', function () {
      $('.hidden-filters').slideDown('fast');
    });
    $('.profile-link').on('click', function () {
      $('.hidden-filters').slideUp('fast');
    });
  };


  self.toggleMorePaymentMethods = function () {
    $('.show-more-payment-methods, .hide-more-payment-methods').on('click', function () {
      $('.more-payment-methods').slideToggle('fast');
      $('.show-more-payment-methods, .hide-more-payment-methods').toggle();
    });
  };

  self.toggleSendAction = function () {
    $('.search-btn-row .search-button').on('click', function () {
      $('.button-group-action').css('display', 'flex');
    });
  };

  self.initStudentSearchTable = function () {
    if (!$('.search-table').length) {
      return;
    }

    $('.search-table').each(function () {
      let dom = 'ftilpr';

      $(this).hasClass('no-pagination') && (dom = dom.replace('lp', ''));


      let lengthMenu = [[10, 25, 50, -1], [10, 25, 50, "All"]];
      if ($(this).hasClass('transaction-history-table')) {
        lengthMenu = [[5, 15, -1], [5, 15, "All"]];
      }

      $(this).DataTable({
        "searching": $(this).hasClass('enable-searching') || false,
        "info": false,
        "dom": dom,
        "bSort": false,
        "lengthMenu": lengthMenu,
        language: {
          sLengthMenu: "_MENU_",
          search: "_INPUT_",
          searchPlaceholder: "Search",
          paginate: {
            next: '<i class="next-icon" title="Next"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
              '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M15.581 11.406a.548.548 0 0 0 0 .772l2.545 2.554h-9.7a.545.545 0 0 0 0 1.09h9.7l-2.55 2.554a.552.552 0 0 0 0 .772.543.543 0 0 0 .767 0l3.457-3.486a.612.612 0 0 0 .113-.172.52.52 0 0 0 .042-.21.547.547 0 0 0-.155-.38l-3.455-3.481a.534.534 0 0 0-.764-.013z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
              '</svg>\n</i>',
            previous: '<i class="prev-icon" title="Previous"><svg width="12.073" height="8.052" viewBox="0 0 12.073 8.052">\n' +
              '    <path id="prefix__Icon_ionic-ios-arrow-round-back" fill="#8dc24c" d="M12.256 11.406a.548.548 0 0 1 0 .772l-2.541 2.553h9.7a.545.545 0 0 1 0 1.09h-9.7l2.55 2.554a.552.552 0 0 1 0 .772.543.543 0 0 1-.767 0l-3.461-3.485a.612.612 0 0 1-.113-.172.52.52 0 0 1-.042-.21.547.547 0 0 1 .155-.382l3.455-3.481a.534.534 0 0 1 .764-.011z" data-name="Icon ionic-ios-arrow-round-back" transform="translate(-7.882 -11.252)"/>\n' +
              '</svg>\n</i>'
          },
        },
      });
    });

    $(document).on('click', '.search-table-change-page-length', function () {
      var table = $(this).attr('data-target-table');
      var pageLength = $(this).attr('data-page-length');

      $(table).parent().find('.dataTables_length select').val(pageLength);
      $(table).parent().find('.dataTables_length select').trigger('change');

      $('.search-table-page-length').text(pageLength != -1 ? pageLength : 'All');
    });
  };

  self.handleStudentSearchTableCheckboxes = function () {
    $(document).on('change', '.search-table td .custom-checkbox', function () {
      var parentTable = $(this).closest('table');
      var totalCheckboxes = parentTable.find('td .custom-checkbox input').length;
      var checkedCheckboxes = parentTable.find('td .custom-checkbox input:checked').length;
      var minimumCheckboxSelectionCount = parentTable.hasClass('single-checkbox-selection-bar') ? 1 : 2;

      $('.selected-student-checkboxes-count').text(checkedCheckboxes || 1);

      if (checkedCheckboxes >= minimumCheckboxSelectionCount) {
        $('.checkbox-selection-bar').fadeIn('fast');
        parentTable.find('.disable-on-checkbox-selection').attr('disabled', true);
      } else {
        $('.checkbox-selection-bar').fadeOut('fast');
        parentTable.find('.disable-on-checkbox-selection').attr('disabled', false);
      }

      if (totalCheckboxes == checkedCheckboxes) {
        parentTable.find('.select-all-student-search-checkboxes input').prop('checked', true);
      } else {
        parentTable.find('.select-all-student-search-checkboxes input').prop('checked', false);
      }
    });

    $('.search-table').on('page.dt', function () {
      $(this).find('td .custom-checkbox input:checked').click();
    });

    $('a[data-toggle="tab"]').on('show.bs.tab', function () {
      $('.search-table td .custom-checkbox input:checked').click();
    });

    $('.deselect-student-search-checkboxes').on('click', function () {
      $('.search-table td .custom-checkbox input:checked').click();
    });

    $('.select-all-student-search-checkboxes').on('change', function () {
      var parentTable = $(this).closest('table');
      if ($(this).find('input').prop('checked')) {
        parentTable.find('td .custom-checkbox input:not(:checked)').click();
      } else {
        parentTable.find('td .custom-checkbox input:checked').click();
      }
    });
  };

  self.handleMultipleTabContents = function () {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
      var previousSecondTarget = $(e.relatedTarget).attr('data-second-target');
      var nextSecondTarget = $(e.target).attr('data-second-target');

      previousSecondTarget && $(previousSecondTarget).removeClass('show active');
      nextSecondTarget && $(nextSecondTarget).addClass('show active');

      self.resizeGraphs();
    });
  };

  self.toggleProfileSnapshot = function () {
    $('.show-profile-snapshot').on('click', function () {
      $('.show-profile-snapshot').hide();
      $('.show-profile-details').fadeIn();

      $('.profile-details-content').hide();
      $('.profile-snapshot-content').fadeIn();

      $('.student-action-btn').fadeOut();

      self.resizeGraphs();
    });

    $('.show-profile-details').on('click', function () {
      $('.show-profile-details').hide();
      $('.show-profile-snapshot').fadeIn();

      $('.profile-snapshot-content').hide();
      $('.profile-details-content').fadeIn();

      $('.student-action-btn').fadeIn();
    });
  };

  self.handleSearchField = function () {
    $('.search-field').on('keyup click', function () {
      if ($(this).find('input').val() != '') {
        $(this).addClass('has-value');
        $(this).find('.search-field-results').slideDown('fast');
      }
      else {
        $(this).removeClass('has-value');
        $(this).find('.search-field-results').slideUp('fast');
      }
    });

    $('.search-field .clear-search-field').on('click', function () {
      $(this).siblings('input').val('');
      $(this).siblings('input').trigger('change').trigger('keyup').trigger('keydown');
      $(this).closest('.search-field').removeClass('has-value');
    });

    $('.search-field-results').on('click', function () {
      $(this).siblings('input').val('');
      $(this).siblings('input').trigger('change').trigger('keyup').trigger('keydown');
      $(this).closest('.search-field').removeClass('has-value');
    });

    $(document).on('click', function (e) {
      var container = $('.search-field input');
      if (!container.is(e.target) && container.has(e.target).length === 0) {
        $('.search-field-results').slideUp('fast');
      }
    });
  };

  self.handleTodoList = function () {
    $(document).on('click', '.todo-list li', function () {
      $(this).toggleClass('active')
    });

    $(document).on('click', '.todo-move-ltr', function () {
      var selectedItems = $('.todo-list-left li.active');
      selectedItems.removeClass('active');
      $('.todo-list-right').append(selectedItems);
      checkForEmptyList();
    });

    $(document).on('click', '.todo-move-rtl', function () {
      var selectedItems = $('.todo-list-right li.active');
      selectedItems.removeClass('active');
      $('.todo-list-left').append(selectedItems);
      checkForEmptyList();
    });

    function checkForEmptyList() {
      $('.todo-list-left li').length ? $('.empty-list-left').hide() : $('.empty-list-left').fadeIn('fast');
      $('.todo-list-right li').length ? $('.empty-list-right').hide() : $('.empty-list-right').fadeIn('fast');
    }
  };

  self.handleDetailsPopover = function () {
    $('[details-popover-target]').each(function () {
      var elem = $(this);
      var target = elem.attr('details-popover-target');
      var placement = elem.attr('details-popover-placement') || 'auto';
      var template = $(target).contents();

      elem.popover('dispose');
      var popover = elem.popover({
        animation: true,
        trigger: 'manual',
        html: true,
        container: 'body',
        content: template,
        boundary: 'viewport',
        popperConfig: {
          placement: placement,
        },
      })

      if (WindowWidth > MobileWidth) {
        popover.hover(function (evt) {
          elem.popover('toggle');
          $('.popover').addClass('details-popover ' + placement);
          evt.stopPropagation();
        })
      } else {
        popover.click(function (evt) {
          elem.popover('toggle');
          $('.popover').addClass('details-popover ' + placement);
          evt.stopPropagation();
        });

        $('body').on('click', function (e) {
          elem.popover('hide');
        });
      }
    })
  };

  self.handleVerticalSteps = function () {
    $(document).on('change', '.on-change-move-to-next-step', function () {
      moveToNextStep($(this));
    });

    $(document).on('click', '.move-to-next-step', function () {
      moveToNextStep($(this));
    });

    function moveToNextStep(elem) {
      var verticalStepsSection = elem.closest('.vertical-steps-section');

      verticalStepsSection.addClass('completed');
      verticalStepsSection.find('input, select, textarea').attr('disabled', true);
      verticalStepsSection.next().addClass('current');
    }

    $(document).on('click', '.reset-steps', function () {
      var verticalStepsWrapper = $(this).closest('.vertical-steps-wrapper');
      verticalStepsWrapper
        .find('.vertical-steps-section')
        .removeClass('completed')
        .removeClass('current')
        .first()
        .addClass('current');
      verticalStepsWrapper.find('input, select, textarea').attr('disabled', false);
    });
  };

  self.handleToolTip = function () {
    $('.popover-container button').click(function () {
      $('.tool-tip').addClass('show');
    });
    $('#close-icon').on('click', function () {
      $('.tool-tip').removeClass('show');
    });

    $(document).mouseup(function (e) {
      var popup = $(".tool-tip");
      if (!$('.popover-container button').is(e.target) && !popup.is(e.target) && popup.has(e.target).length == 0) {
        popup.removeClass('show');
      }
    });
    if (WindowWidth < MobileWidth) {
      $('.tool-tip').removeClass('left right top');
      $('.tool-tip').addClass('bottom');
    }
  };

  self.handleProgressSteps = function () {
    $(document).on('click', '.move-to-second-step', function () {
      var progressStep = $('.progress-step:first-child');

      progressStep.addClass('completed');
      progressStep.removeClass('current').next().addClass('current');
    });
  };

  self.handleToggleEvents = function () {
    $(document).on('click', '.toggle-on-click', function (event) {
      event.preventDefault();
      var target = $(this).attr('data-target') || $(this).attr('href');

      if ($(this).hasClass('quick-toggle')) {
        $(target).toggle();
      } else {
        $(target).fadeToggle('fast');
      }
    });

    $(document).on('change keyup', '.show-on-change', function () {
      var target = $(this).attr('data-target');

      if ($(this).hasClass('check-for-value') && !$(this).val()) {
        $(target).fadeOut('fast');
        return;
      }

      $(target).fadeIn('fast');
    });

    $(document).on('click', '.disable-on-click', function (event) {
      event.preventDefault();
      var target = $(this).attr('data-target') || $(this).attr('href');

      $(target).prop('disabled', function(index, value) { return !value; });
    });
  };

  self.initBarcodes = function () {
    $.fn.JsBarcode && JsBarcode(".barcode").init();
  };

  self.initMiniCalendar = function () {
    $('.mini-calendar-example').each(function () {
      var holidays = [];
      if ($(this).hasClass('show-sample-holidays')) {
        holidays = [
          new Date(2020, 6, 10),
          new Date(2000, 10, 10, 30, 0)
        ]
      }

      $(this).kendoCalendar({
        dates: holidays,
        month: {
          content: "<span class='#= isInArray(data.date, data.dates) ? \'holiday\' : \'\' #'>#= data.value #</span>"
        }
      });
    });
  };

  self.initFullCalendar = function () {
    if (!window.FullCalendar) {
      return;
    }

    var sampleEvents = [
      {
        title: "Long Event",
        start: "2020-08-02T19:30:00+00:00",
        end: "2020-08-02T21:30:00+00:00",
        type: 'upcoming',
        heading: 'Arabic HLTP1 Student Thinking (July Start)',
        startDate: 'Mon, 24/July/2020 - 12.30',
        endDate: 'Mon, 24/July/2020 - 13.00',
        location: 'DUBAI',
        qrCode: '20003445678',
        trainers: 'Marcus Anthony, Abu Munzal',
        category: 'Management Learning, 1 Day Course',
        text: 'Management Learning is a peer-reviewed academic journal that publishes papers in the field of management five times per year. The journal’s editors are Emma Bell and Todd Bridgman. The journal was established in 1970 and is published by SAGE Publications.',
        moreText: 'Management Learning is a peer-reviewed academic journal that publishes papers in the field of management five times per year. The journal’s editors are Emma Bell and Todd Bridgman. The journal was established in 1970 and is published by SAGE Publications.',
        image: 'assets/images/map-img.jpg'
      },
      { title: "Conference", start: "2020-08-06", end: "2020-08-08", type: 'upcoming' },
      { title: "Meeting", start: "2020-08-05T10:30:00+00:00", end: "2020-08-05T12:30:00+00:00", type: 'upcoming' },
      { title: "Lunch", start: "2020-08-05T12:00:00+00:00", end: "2020-08-05T13:00:00+00:00", type: 'upcoming' },
      { title: "Birthday Party", start: "2020-08-08T05:00:00+00:00", end: "2020-08-08T06:00:00+00:00", type: 'cancelled' },
      { title: "Meeting", start: "2020-08-02T08:30:00+00:00", type: 'completed' },
      { title: "Happy Hour", start: "2020-08-04T12:30:00+00:00", type: 'upcoming' },
      { title: "Dinner", start: "2020-08-05T20:00:00+00:00", end: "2020-08-05T21:00:00+00:00", type: 'completed' }
    ];

    // ****************************************
    // Demo for changing locale
    // https://fullcalendar.io/docs/locale-demo
    // ****************************************
    var defaultLanguage = 'en';
    var arabicLanguage = 'ar-sa';

    $('.full-calendar-wrapper').each(function () {
      var calendarWrapper = $(this);
      var calendarEl = calendarWrapper.find('.full-calendar')[0];
      var calendar = new FullCalendar.Calendar(calendarEl, {
        locale: localStorage.getItem('language') === 'Ar' ? arabicLanguage : defaultLanguage,
        initialView: 'timeGridWeek',
        height: 'auto',
        headerToolbar: {
          left: '',
          center: 'prev,title,next',
          right: 'today,dayGridMonth,timeGridWeek,listWeek'
        },
        scrollTime: '00:00:00',
        titleFormat: { year: 'numeric', month: 'short', day: '2-digit' },
        dayHeaderFormat: { weekday: 'short', day: 'numeric' },
        // allDaySlot: false,
        stickyHeaderDates: false,
        eventTimeFormat: {
          hour: 'numeric',
          minute: '2-digit',
          meridiem: true,
        },
        dayHeaderContent: function (arg) {
          var arrayOfDomNodes = [];
          var text = arg.text.split(' ');
          
          var date = document.createElement('div');
          date.className = 'fc-col-header-date';
          date.innerHTML = isNaN(text[0]) ? text[1] : text[0];

          var day = document.createElement('div');
          day.className = 'fc-col-header-day';
          day.innerHTML = isNaN(text[0]) ? text[0] : text[1];

          switch(arg.view.type) {
            case 'timeGridWeek': 
              arrayOfDomNodes = [ day, date ];
              break;
            case 'listWeek':
              arrayOfDomNodes = [ day ];
              break;
            default:
              arrayOfDomNodes = [ day ];
          }

          return { domNodes: arrayOfDomNodes };
        },
        slotLabelFormat: { hour: 'numeric', minute: '2-digit', meridiem: false, hour12: false },
        events: sampleEvents,
        eventDidMount: function (event) {
          var elem = $(event.el);
          elem.addClass(event.event.extendedProps.type);

          if (calendarWrapper.find('.full-calendar-event-popover-template').length) {
            var template = calendarWrapper.find('.full-calendar-event-popover-template').clone();
            var fallbackValue = "N/A";
            template.find('[data-value]').each(function () {
              var text = event.event.extendedProps[$(this).attr('data-value')] || fallbackValue;
              $(this).text(text);
            });

            if (event.event.extendedProps.moreText) {
              template.find('.show-more-text').removeClass('hidden');
            }

            if (event.event.extendedProps.image) {
              template.find('.event-popover-image').attr('src', event.event.extendedProps.image);
              template.find('.event-popover-image').removeClass('hidden');
            }

            elem.popover('dispose');
            elem.popover({
              animation: true,
              trigger: 'manual',
              html: true,
              container: 'body',
              placement: elem.hasClass('fc-list-event') ? 'left' : 'auto',
              content: template.html(),
              boundary: 'viewport',
            }).click(function (evt) {

              // REMOVING EXISTING POPOVER
              var existingPopoverId = $('.popover').attr('id');
              if (existingPopoverId) {
                $("[aria-describedby=" + existingPopoverId + "]").popover('hide').toggleClass('active');
              }
              elem.popover('toggle');
              $('.popover').addClass('full-calender-event-popover');

              evt.stopPropagation();
            });

            $(document).on('click', function (e) {
              var container = $('.popover');
              if (!container.is(e.target) && container.has(e.target).length === 0) {
                elem.popover('hide');
              }
            });
          }

        },
      });

      calendar.render();

      $(this).find('.fc-toolbar-chunk').first().append($(this).find('.full-calender-header-left').html());
      $(this).find('.fc-toolbar-chunk').last().append($(this).find('.full-calender-header-right').html());

      $('.lang_select select').on('change', function () {
        language = $(this).val();
        calendar.setOption('locale', language === 'Ar' ? arabicLanguage : defaultLanguage);
      });      
    });
  };

  self.handleQuickLinksCarousel = function () {
    if (!$('.my-quick-links-container').length) {
      return;
    }
    var scrollingOffset = $('.my-quick-links-container').width() / 2;

    if ($('.my-quick-links-container').get(0).scrollWidth === $('.my-quick-links-container').outerWidth()) {
      $('.quick-links-arrow.right').addClass('disabled');
    }

    $('.quick-links-arrow').on('click', function () {
      if ($(this).hasClass('left')) {
        $('.my-quick-links-container').animate(
          {
            scrollLeft: $('.my-quick-links-container').scrollLeft() - scrollingOffset
          },
          300
        );
      }
      else {
        $('.my-quick-links-container').animate(
          {
            scrollLeft: $('.my-quick-links-container').scrollLeft() + scrollingOffset
          },
          300
        );
      }
    });

    $('.my-quick-links-container').on('scroll', function () {
      self.updateQuickLinkArrows();
    });

    self.updateQuickLinkArrows();
  };

  self.updateQuickLinkArrows = function () {
    if (!$('.my-quick-links-container').length) {
      return;
    }

    // Condition For Left Arrow
    if ($('.my-quick-links-container').scrollLeft() === 0) {
      $('.quick-links-arrow.left').addClass('disabled');
    }
    else {
      $('.quick-links-arrow.left').removeClass('disabled');
    }

    // Condition For Right Arrow
    var scrollingWidth = $('.my-quick-links-container').get(0).scrollWidth;
    var innerWidth = $('.my-quick-links-container').innerWidth();
    var scrollLeft = Math.round($('.my-quick-links-container').scrollLeft());

    if (Math.round(scrollingWidth - innerWidth - scrollLeft) === 0) {
      $('.quick-links-arrow.right').addClass('disabled');
    }
    else {
      $('.quick-links-arrow.right').removeClass('disabled');
    }
  }

  self.handleFontSize = function () {
    self.fontZoomLevel = localStorage.getItem('fontZoomLevel') || 0;
    self.updateFontSize(self.fontZoomLevel);

    $('.a-plus-text').on('click', function () {
      $('html').css("font-size", "+=2");
      self.fontZoomLevel++;
      saveFontZoomLevel(self.fontZoomLevel);
    });

    $('.a-minus-text').on('click', function () {
      $('html').css("font-size", "-=2");
      self.fontZoomLevel--;
      saveFontZoomLevel(self.fontZoomLevel);
    });

    $('.a-text').on('click', function () {
      self.fontZoomLevel = 0;
      self.updateFontSize(0);
      saveFontZoomLevel(self.fontZoomLevel);
    });

    function saveFontZoomLevel(fontZoomLevel) {
      localStorage.setItem('fontZoomLevel', fontZoomLevel);
      self.updateFontButtons(fontZoomLevel);
    };
  }

  self.updateFontSize = function (fontZoomLevel) {
    var offset = 2 * fontZoomLevel || 0;
    $('html').css("font-size", 16 + offset + 'px');
    self.updateFontButtons(fontZoomLevel);
  };

  self.updateFontButtons = function (fontZoomLevel) {
    $('.a-plus-text, .a-minus-text').removeClass('disabled');

    if (fontZoomLevel >= 2) {
      $('.a-plus-text').addClass('disabled');
    }
    else if (fontZoomLevel <= -2) {
      $('.a-minus-text').addClass('disabled');
    }
  };

  self.updateOrganizationRowAfterWidth = function() {
    $('#organization-chart-modal').on('shown.bs.modal', function (e) {
      if(!$('.organisation-row.has-multiple-children').length) {
        return;
      }

      $('.organisation-row.has-multiple-children').each(function(){
        var itemWidth = $(this).find('.organisation-item').first().width();
        var width = $(this).width() - itemWidth + 2;

        $('<style>'+ '.organisation-row.has-multiple-children:after { width: '+ (width || 500) + 'px; }</style>').appendTo('head');
      });
    })
  }

  self.handleDashboardDragnDrop = function() {
    $(document).on('click', '.user-dashboard-drag-n-drop', function() {
      $('.card').addClass('draggable');
    });

    $(document).on('click', '.user-dashboard-drag-n-drop-cancel, .user-dashboard-drag-n-drop-save', function() {
      $('.card').removeClass('draggable');
    });
  }

  self.handleConfigSearch = function() {
    $('.config-search input').on('keyup', function() {
      var keyword = $(this).val().toLowerCase();
      $('.config-container').each(function(){
        $(this).find('li').each(function() {
          if ($(this).text().toLowerCase().indexOf(keyword) === -1) {
            $(this).hide();
          }
          else {
            $(this).show();
          }
        }); 

        if(!$(this).find('li:visible').length) {
          $(this).find('.no-links').show();
        } else {
          $(this).find('.no-links').hide();
        }
      });
    })
  };

};

var ph = new Phoenix();

$(document).ready(function () {
  ph.init_when_ready();
});
$(window).on('load', function () {
  ph.init_after_load();
});
$(window).resize(function () {
  ph.init_on_resize();
});
$(document).scroll(function () {
  ph.init_on_scroll();
});

$(document).on('keyup', '.dataTables_filter input', function () {
  if ($(this).val()) {
    $(this).closest('label').addClass('handle-icon');
  } else {
    $(this).closest('label').removeClass('handle-icon');
  }
});